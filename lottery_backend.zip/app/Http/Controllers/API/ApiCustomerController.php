<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\DocumentsModel;
use App\Model\JobsModel;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use App\User;
use App\Model\InsuranceModel;
use JWTAuth;
use App\Model\CompanyModel;
use App\Model\QuotationModel;

class ApiCustomerController extends Controller
{
    public function uploadFile(Request $request)
    {
        $validator = Validator::make($request->all(), [
                  'photo' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json(['message' => 'Submit error', 'data' => $validator->errors(), 'response_code' => 0], 200);
        }
        try {
            $url = asset('/').'storage/app/'.((Storage::disk('local')->put('/public/photos', $request->photo)));
            return response()->json(['message' => 'success', 'data' => $url, 'response_code' => 1], 200);
        } catch (\Exception $e) {
            return response()->json(['message' => 'upload failed', 'data' => $e, 'response_code' => 0], 500);
        }
    }

    public function addDocuments(Request $request)
    {
        // uploading multiple documents

        $validator = Validator::make($request->all(), [
                  'document' => 'required'

        ]);
        if ($validator->fails()) {
            return response()->json(['message' => 'Submit error', 'data' => $validator->errors(), 'response_code' => 0], 200);
        }
        $documentArr = array();
        if (empty($request->document)) {
            return response()->json(['message' => 'No file uploaded', 'data' => null, 'response_code' => 0], 200);
        }
        try {
            foreach ($request->document as $docfile) {
                $document = asset('/').'storage/app/'.((Storage::disk('local')->put('/public/uploads/documents', $docfile)));
                array_push($documentArr, $document);
            }
        } catch (\Exception $e) {
            return response()->json(['message' => 'upload failed', 'data' => $e, 'response_code' => 0], 500);
        }
        return response()->json(['message' => 'success', 'data' => $documentArr, 'response_code' => 1], 200);
    }

    protected function validator(array $data)
    {
        return Validator::make($data, [
                'username' => 'required|string|max:255',
                'email' => 'required|string|email|max:255|unique:users',
                'password' => 'required|string|min:6',
                'phoneno' => 'required|string|max:255',
                'devicename' => 'required|string|max:255',
                'usertype' => 'required|string|max:255'
          ], $messages);
    }
    // create job records.
    public function addJob(Request $request)
    {
        $user = JWTAuth::parseToken()->authenticate();
        if ($user->usertype=="agent") {
            return response()->json(['message' => 'This Account is no customer', 'data' => null, 'response_code' => 0], 200);
        }
        $validator = Validator::make($request->all(), [
          'name' => 'required',
          'nric' => 'required',
          'phoneno' => 'required',
          'address' => 'required',
          'state' => 'required',
          'country' => 'required',
          'company_id' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json(['message' => 'Submit error', 'data' => $validator->errors(), 'response_code' => 0], 200);
        }
        ($request->username != null) ? $request->username : $user->username;
        $userid = $user->id;
        $name = $request->name;
        $nric = $request->nric;
        $phone = $request->phoneno;
        if ($request->insurencetype != null) {
            $instype = $request->insurencetype;
        }
        if ($request->indicative_sum != null) {
            $sum = $request->indicative_sum;
        }
        $address = $request->address;
        $pcode = $request->postcode;
        $state = $request->state;
        $country = $request->country;
        if ($request->expired_date != null) {
            $expired_date = $request->expired_date;
        }
        $company_id = $request->company_id;
        // create jobs transaction record
        $jobmodel = new JobsModel();
        $jobmodel->user_id = $userid;
        $jobmodel->name = $name;
        $jobmodel->nric = $nric;
        $jobmodel->phoneno = $phone;
        if ($request->insurencetype != null) {
            $jobmodel->insurance_type = $instype;
        }
        if ($request->indicative_sum != null) {
            $jobmodel->indicative_sum = $sum;
        }
        $jobmodel->address = $address;
        $jobmodel->postcode = $pcode;
        $jobmodel->state = $state;
        $jobmodel->country = $country;
        $jobmodel->job_status = 0;
        if ($request->expired_date != null) {
            $jobmodel->expired_date = $expired_date;
        }
        $jobmodel->company_id = $company_id;
        try {
            $result = $jobmodel->save();
            if ($result) {
                // Update documents table
                foreach ($request->documents as $docurl) {
                    $document = new DocumentsModel();
                    $document->user_id = $userid;
                    $document->job_id = $jobmodel->id;
                    $document->fileName = $docurl;
                    $document->save();
                }
                $jobCreated['job'] = $jobmodel;
                $jobCreated['documents'] = DocumentsModel::where(['job_id' => $jobmodel->id])->get();
                return response()->json(['message' => 'New job is created', 'data' => $jobCreated, 'response_code' => 1], 200);
            } else {
                return response()->json(['message' => 'Create job problem', 'data' => null, 'response_code' => 0], 200);
            }
        } catch (\Exception $exception) {
            return response()->json(['message' => 'Server Error', 'data' => $exception, 'response_code' => 0], 500);
        }
    }
    /**
     * fetching job posted by a particular user api
     */
    public function fetchJob(Request $request)
    {
        $user = JWTAuth::parseToken()->authenticate();
        try {
            if ($user->usertype == 'agent') {
                $userJobs = JobsModel::join('users', 'users.id', '=', 'jobs.user_id')
                ->select()
                ->addSelect('jobs.id as job_id')
                ->addSelect('jobs.address as job_address')
                ->addSelect('users.address as usr_address')
                ->get();
                $jobData = array();
                foreach ($userJobs as $userJob) {
                    $insuranceData = InsuranceModel::findOrFail($userJob['insurance_type']);
                    $userJob['documents'] = DocumentsModel::where(['job_id'=>$userJob->job_id])->get();
                    $userJob['insurance'] = $insuranceData;
                    $userJob['quotation'] = QuotationModel::where(['agent_id'=>$user->id, 'job_id'=>$userJob->job_id])->first();
                    $userJob['company'] = CompanyModel::findOrFail($userJob->company_id);
                    array_push($jobData, $userJob);
                }
                if (count($jobData) > 0) {
                    return response()->json(['message' => 'All  posted jobs by cutomer', 'data' => $jobData, 'response_code' => 1], 200);
                } else {
                    return response()->json(['message' => 'there is no posted jobs', 'data' => null, 'response_code' => 0], 200);
                }
            } else {
                $userJobs = JobsModel::join('users', 'users.id', '=', 'jobs.user_id')
                  ->where(['user_id' => $user->id])
                  ->select()
                  ->addSelect('jobs.id as job_id')
                  ->addSelect('jobs.address as job_address')
                  ->addSelect('users.address as usr_address')
                  ->get();
                $jobData = array();
                foreach ($userJobs as $userJob) {
                    $insuranceData = InsuranceModel::findOrFail($userJob['insurance_type']);
                    $userJob['documents'] = DocumentsModel::where(['job_id'=>$userJob->job_id])->get();
                    $userJob['insurance'] = $insuranceData;
                    $userJob['quotation'] = QuotationModel::where(['job_id'=>$userJob->job_id])->first();
                    $userJob['company'] = CompanyModel::findOrFail($userJob->company_id);
                    array_push($jobData, $userJob);
                }
                if (count($jobData) > 0) {
                    return response()->json(['message' => 'All  created jobs by person', 'data' => $jobData, 'response_code' => 1], 200);
                } else {
                    return response()->json(['message' => 'No job is created by this person', 'data' => null, 'response_code' => 0], 200);
                }
            }
        } catch (\Exception $exception) {
            return response()->json(['message' => 'Server Error', 'data' => $exception, 'response_code' => 0], 500);
        }
    }
    // GET Job Details
    public function jobDetail(Request $request)
    {
        $user = JWTAuth::parseToken()->authenticate();
        if ($request->has('jobId')) {
            try {
                $insurances = InsuranceModel::all();
                $userJobs = JobsModel::where(['id'=>$request->jobId])->first();
                $jobData = array();
                if ($user->usertype == 'agent') {
                    $documents = DocumentsModel::where('job_id' , '=' ,$userJobs->id)->where(function ($query) use ($user, $request) {
                        $query->where('user_id', '=', $user->id)
                        ->orWhere('user_id', '=', $request->customer_id);
                    })->get();
                } else {
                    $documents = DocumentsModel::where('job_id' , '=' ,$userJobs->id)->where(function ($query) use ($user, $request) {
                        $query->where('user_id', '=', $user->id)
                        ->orWhere('user_id', '=', $request->agent_id);
                    })->get();
                }
                if (count($insurances) > $userJobs->insurance_type) {
                    $insuranceData = InsuranceModel::findOrFail($userJobs->insurance_type);
                    $userJobs['insurance_id'] = $insuranceData->id;
                    $userJobs['insurance_name'] = $insuranceData->insurance_name;
                }
                $companies = CompanyModel::all();
                if (count($companies) > $userJobs->company_id) {
                    $userJobs['company'] = CompanyModel::findOrFail($userJobs->company_id);
                }
                $userJobs['documents'] = $documents;
                if ($userJobs) {
                    return response()->json(['message' => 'job', 'data' => $userJobs, 'response_code' => 1], 200);
                } else {
                    return response()->json(['message' => 'No job is created by this person', 'data' => null, 'response_code' => 0], 200);
                }
            } catch (\Exception $exception) {
                return response()->json(['message' => 'Server Error', 'data' => $exception, 'response_code' => 0], 500);
            }
        } else {
            return response()->json(['message' => 'job id not given', 'data' => null, 'response_code' => 0], 200);
        }
    }

    //GET Quot document
    public function getQuotDocument(Request $request)
    {
        $user = JWTAuth::parseToken()->authenticate();
        if ($user->usertype == "agent") {
            return response()->json(['message' => 'must be customer', 'data' => null, 'response_code' => 0], 200);
        }
        if ($request->has('jobId') && $request->has('user_id')) {
            try {
                $documents = DocumentsModel::where('job_id' , '=' ,$request->jobId)->where(function ($query) use ($user, $request) {
                    $query->where('user_id', '=', $user->id)
                    ->orWhere('user_id', '=', $request->user_id);
                })->get();
                //$documents = DocumentsModel::where(['job_id' => $request->jobId,'user_id' => $request->user_id])->get();
                if (count($documents) > 0) {
                    return response()->json(['message' => 'Documents', 'data' => $documents, 'response_code' => 1], 200);
                } else {
                    return response()->json(['message' => 'No Documents', 'data' => null, 'response_code' => 0], 200);
                }
            } catch (\Exception $exception) {
                return response()->json(['message' => 'Server Error', 'data' => $exception, 'response_code' => 0], 500);
            }
        } else {
            return response()->json(['message' => 'jobId or user_id not given', 'data' => null, 'response_code' => 0], 200);
        }
    }

    public function getInsuranceType(Request $request)
    {
        if (!empty($request->insurId)) {
            try {
                $insuranceData = InsuranceModel::findOrFail($userJobs[$i]['insurance_type']);
                $insuranceData->companys;
                $send_data = array('insurance_name'=>$InsuranceData->insurance_name,'id'=>$InsuranceData->id );

                if (count($InsuranceData) > 0) {
                    return response()->json(['message' => 'insurance', 'data' => $send_data, 'response_code' => 1], 200);
                } else {
                    return response()->json(['message' => 'No insurance is no data', 'data' => null, 'response_code' => 0], 200);
                }
            } catch (\Exception $exception) {
                return response()->json(['message' => 'Server Error', 'data' => null, 'response_code' => 0], 500);
            }
        } else {
            $InsuranceDatas = InsuranceModel::all();
            $send_data = [];
            foreach ($InsuranceDatas as $InsuranceData) {
                $send_data[] = array(
                  'insurance_name'=>$InsuranceData->insurance_name,
                  'id'=>$InsuranceData->id,
                  'companys'=>$InsuranceData->companys
              );
            }

            if (count($InsuranceDatas) > 0) {
                return response()->json(['message' => 'insurance', 'data' => $send_data, 'response_code' => 1], 200);
            } else {
                return response()->json(['message' => 'There is no INsurance Data', 'data' => [], 'response_code' => 0], 200);
            }
        }
    }
}

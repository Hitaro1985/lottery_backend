<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Role;
class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::user();
        $user_role = Role::where('id', $user->role_id)->first();
        $bets = array();
        for( $i = 0; $i <= 36; $i ++) {
            if( $i % 3 == 0){
                $bets[$i]['exist'] = '1';
                $bets[$i]['bet'] = '3.00';
                $bets[$i]['1st'] = '240.00';
                $bets[$i]['2st'] = '240.00';
                $bets[$i]['3st'] = '240.00';
            }
            else if( $i % 16 == 0) {
                $bets[$i]['exist'] = '0';
            }
            else {
                $bets[$i]['exist'] = '-1';
            }
            
        }
        return view('admin.dashboard', ['bets' => $bets, 'user_role' => $user_role['role']]);
    }
}
